<div class="footer" id="footer">
	<div class="container text-center">
		<div class="row">
			<div class="col-12">
				 @COPYRIGHT SEPA2
			</div>
		</div>
		<div class="row">Found Us At:</div>
		<div class="row">
			<div class="col-4">
				<div class="socmed">
					sepasepa
				</div>
			</div>
			<div class="col-4">
				<div class="socmed">
					@_sepa2
				</div>
			</div>
			<div class="col-4">
				<div class="socmed">
					@sepatwo
				</div>
			</div>
		</div>
	</div>
</div>