<div>
	<ul class="navbar navbar-black">
		<li class="nav-item nav-item-right"><a class="item" href="logout">Logout</a></li>
		<li class="nav-item nav-item-right"><a class="item" href="/sepa2">Home</a></li>
	</ul>
</div>