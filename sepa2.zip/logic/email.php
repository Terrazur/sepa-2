<?php
$user = $_SESSION['user'];
$to      = 'williamtheodore007@yahoo.co.id';
$subject = 'Email Activation';
$message = 'Hello'.$user.', Thankyou to activate your account now you are able to buy form our vast collection of shoes';
$headers = 'From: sepa2@yandex.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);

	if(@mail($to, $subject, $message, $headers)){
		header("Location: profile");
	}
	else{
		$alert = "Mail Not Sent";
		header("Location: reEmail");
?>
	
<?php } ?>
