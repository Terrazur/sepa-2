<?php
	$servername="mysql.hostinger.com";
	$username="u504735934_root";
	$password="Sepatwo050618";
	$db_name="u504735934_ebis";

	// connect
	$connect=new mysqli($servername,$username,$password,$db_name);

	if(!$connect){
		die("Connect failed");
	}
?>